package com.forexgeniusnj;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.widget.*;
import android.view.View;
import android.graphics.Color;

public class MainActivity extends Activity {
    private TextView status;
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(32,48,32,32);
        layout.setBackgroundColor(Color.rgb(12,20,30));
        TextView title = new TextView(this);
        title.setText("Forex Genius NJ");
        title.setTextSize(28); title.setTextColor(Color.WHITE);
        layout.addView(title);
        TextView sub = new TextView(this);
        sub.setText("Assistant de scan de graphiques Forex");
        sub.setTextColor(Color.LTGRAY); sub.setTextSize(16);
        layout.addView(sub);
        Button choose = new Button(this);
        choose.setText("Importer une capture de graphique");
        layout.addView(choose);
        status = new TextView(this);
        status.setText("Importe une image pour commencer. L'analyse automatique avancée n'est pas encore activée.");
        status.setTextColor(Color.WHITE); status.setPadding(0,24,0,0);
        layout.addView(status);
        choose.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.setType("image/*");
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            startActivityForResult(intent, 1);
        });
        setContentView(layout);
    }
    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==1 && resultCode==RESULT_OK && data!=null) {
            Uri uri=data.getData();
            status.setText("Capture importée. Cette version prototype ne calcule pas encore de signal BUY/SELL, TP ou SL.");
        }
    }
}
